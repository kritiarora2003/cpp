<html>
<body>

<div style="text-align : center; padding : 100; font-size : 60; font-family : Verdana, Sans-serif">
	STUDENT LOGIN
</div>


<div style="padding-left : 30%">

<form action="check_user.php" method="post"> 

	<table>
		<tr>
			<td style="font-size : 20; font-family : Verdana, Sans-serif">Student ID : </td>
			<td><input type="text" name="sid" style="width : 450px; font-size : 25" required></td>
		</tr>
		<tr>
			<td style="font-size : 20; font-family : Verdana, Sans-serif">Password : </td>
			<td><input type="password" name="pass" style="width : 450px; font-size : 25" required></td>
		</tr>
	</table>

	<br><br>
	<input type="submit" value="SIGN IN" style="font-size : 20; font-family : Verdana, Sans-serif">
</form>

</div>

</body>
</html>

