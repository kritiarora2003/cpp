<html>
<body>


<div style="text-align : center; padding : 100; font-size : 60; font-family : Verdana, Sans-serif">
	STUDENT REGISTRATION
</div>

<div style="padding-left : 25%; font-size : 20; font-family : Verdana, Sans-serif">

User Does Not Exist. 
Please Register to Issue Books.
<br><br><br>

<form action="registration.php" method="post"> 

	<table>
		<tr>
			<td style="font-size : 20; font-family : Verdana, Sans-serif" width=225px>Name :</td> 
			<td><input type="text" name="name" style="width : 500px; font-size : 25" required></td>
		</tr>
		<tr>
			<td style="font-size : 20; font-family : Verdana, Sans-serif">Student ID : </td>
			<td><input type="text" name="sid" style="width : 500px; font-size : 25" required></td>
		</tr>
		<tr>
			<td style="font-size : 20; font-family : Verdana, Sans-serif">Password : </td>
			<td><input type="password" name="pass" style="width : 500px; font-size : 25" required></td>
		</tr>
	</table>

	<br><br>
	<input type="submit" value="SIGN UP" style="font-size : 20; font-family : Verdana, Sans-serif">
</form>

</div>

</body>
</html>
