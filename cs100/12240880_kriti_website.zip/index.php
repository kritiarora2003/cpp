<html>
<?php
include "header.php";
?>
<body>

<div style="text-align : center; padding-bottom : 100; font-size : 25; font-family : Verdana, Sans-serif">
	<b>LIBRARY MANAGEMENT SYSTEM</b>
</div>

<div style="text-align : center; padding : 50">
<span>
<a href="admin.php">
	<button style="width : 280; height : 100; font-size : 30; font-family : Verdana, Sans-serif; border-radius : 5px; border : 2px solid">
		ADMINISTRATOR
	</button>
</a>
</span>
<span>
	&nbsp;
</span>
<span>
<a href="student.php">
	<button style="width : 280; height : 100; font-size : 30; font-family : Verdana, Sans-serif; border-radius : 5px; border : 2px solid">
		STUDENT
	</button>
</a>
</span>
</div>

</body>
</html>
