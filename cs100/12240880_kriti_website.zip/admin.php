<html>
<body>

<div style="text-align : center; padding : 100;font-size : 60; font-family : Verdana, Sans-serif">
	ADMINISTRATOR LOGIN
</div>

<div style="text-align : center; padding : 50;font-size : 30; font-family : Verdana, Sans-serif">

<form action="check_admin.php" method="post"> 
    Password :
    <input type="password" name="adminpass" style="width : 300px; font-size : 30">
</form>

</div>

</body>
</html>
