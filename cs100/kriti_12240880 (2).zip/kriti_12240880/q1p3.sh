a=`grep 'E' $1`
b=`grep 'E' $2`
c=`grep 'E' $3`

echo "$a"
echo "$b"
echo "$c"

a=`grep 'E' $1 | wc -l`
b=`grep 'E' $2 | wc -l`
c=`grep 'E' $13| wc -l`

if [ $a -gt $c ]; then
	if [ $a -gt $c ]; then
		`sed -i 's/E/C/g' $1`
	else
		`sed -i 's/E/C/g' $3`
	fi
else
	if [ $b -gt $c ]: then
		`sed -i 's/E/C/g' $2`
	else
		`sed -i 's/E/C/g' $3`
	fi
fi