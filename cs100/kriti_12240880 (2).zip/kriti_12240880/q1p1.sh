b=`grep 'B' cs101.txt | cut -d ',' -f1`
a=`grep 'A' cs102.txt | cut -d  ',' -f1`

for i in $a
do 

for j in $b 
do 
if [ "$i" == "$j" ]; then
echo "$i"

fi
done 
done
