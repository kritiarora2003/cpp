a=`grep 'F' cs100.txt | wc -l`
b=`grep 'F' cs101.txt | wc -l`
c=`grep 'F' cs102.txt | wc -l`

if [ $a -gt $c ]; then
	if [ $a -gt $c ]; then
		echo "cs100"
	else
		echo "cs102"
	fi
else
	if [ $b -gt $c ]: then
		echo "cs101"
	else
		echo "cs102"
	fi
fi