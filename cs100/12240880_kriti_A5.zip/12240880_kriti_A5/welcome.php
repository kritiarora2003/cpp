<html>
<body>

<?php
if($_POST["username"]=="cs100" && $_POST["password"]=="cs100")
echo "Login is Successful";
else
echo "Login is Unsuccessful";
?>


</body>
</html>
