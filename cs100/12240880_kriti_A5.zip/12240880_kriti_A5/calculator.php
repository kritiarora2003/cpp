<html>
<body>
  <?php
    if(isset($_POST["submit"]))
    {
      $a=$_POST["a"];
      $b=$_POST["b"];
      if($_POST["opd"]=="1")
      {
        $sum=$a+$b;
        echo "The sum is $sum";
      }
      if($_POST["opd"]=="2")
      {
        $sub=$a-$b;
        echo "The difference is $sub";
      }
      if($_POST["opd"]=="3")
      {
        $mul=$a*$b;
        echo "The product is $mul";
      }
      if($_POST["opd"]=="4")
      {
        $div=$a / $b;
        echo "The quotient is $div";
      }
    }
   ?>


</body>
</html>
