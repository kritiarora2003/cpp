Question 1: file name digits.sh
Instruction: Just run it normally
type "./digits.sh"

Question 2: file name ques2.sh
Instruction: type "./ques2.sh <file_name>.c"
this file takes C programme files as command line arguements

Question 3: file name ques3.sh
Instruction: press 1 for sign up
2 for login
3 for forgot password
Input the username, name, passoword, and email as per the given constraints in the quesion

